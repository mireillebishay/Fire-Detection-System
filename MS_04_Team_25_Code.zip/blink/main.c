#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>

#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"
#include <hardware/pwm.h>
//#include "pico-onewire/api/one_wire.h"



#define FLAME_SENSOR_PIN 16 //defining the pin for the smoke sensor ---> Sensor 1
#define BUZZER_PIN 17 //defining the pin for the buzzer ---> Actuator 1
#define IN1_PIN 14 //defining the pin for input 1 for the DC Motor ---> Motor and Actuator 2
#define IN2_PIN 15 //defining the pin for input 2 for the DC Motor ---> Motor and Actuator 2
#define EN_A_PIN 2 //defining the pin for enable for the DC Motor ---> Motor and Actuator 2
//#define DS18B20_PIN 26 //defining the pin for the temperature sensor ---> Sensor 1
#define redPin 5 //defining the pin for the red LED ---> Actuator 3 for the smoke sensor
#define bluePin 9 //defining the pin for the blue LED ---> Actuator 4 for the temperature sensor


// Define the delay in seconds
const int delay = 1;
// Define the number of cycles
const int cycles = 10;
// float duty_cycle = 0.5;

bool fire = false;

//The smoke sensor function which detects the presence of smoke, 
//and if there is smoke resulting from the fire: the buzzer will start buzzing, the red LED will turn on, and finally the motor starts working
void flame(){
    //Since it is a negative digital smoke sensor, so when it detects smoke, it gives a zero
    if (gpio_get(FLAME_SENSOR_PIN) == 0) {
    printf("Detected smoke!\n");
        gpio_put(BUZZER_PIN, 1);  // Set Buzzer to HIGH
        gpio_put(IN1_PIN, 0);     // Set IN1 to LOW
        gpio_put(IN2_PIN, 1);     // Set IN2 to HIGH
        gpio_put(EN_A_PIN, 1);    // Set ENA to HIGH
        gpio_put(redPin,true);    // Set LED to HIGH

    }
    //And whenever there is no smoke, it gives a one
    else if (gpio_get(FLAME_SENSOR_PIN) == 1 && !fire) {
        printf("No smoke detected!\n");
        gpio_put(BUZZER_PIN, 0);  // Set Buzzer to LOW
        gpio_put(IN1_PIN, 0);     // Set IN1 to LOW
        gpio_put(IN2_PIN, 0);     // Set IN2 to LOW
        gpio_put(EN_A_PIN, 0);    // Set ENA to LOW
        gpio_put(redPin, false);  // Set LED to LOW
    }
}

//The temperature sensor function which reads the temperature of the enviromnent of the sensor, 
//and if the temperature excedded 45 degrees celsius: the buzzer will start buzzing, the red LED will turn on, and finally the motor starts working
void Temp() {
    // Read raw ADC value from the temperature sensor
    uint16_t result = adc_read();

    // Conversion factor for ADC to voltage (assuming V_REF is 3.3V)
    const float conversion_factor = 3.3f / (1 << 12);

    // Convert ADC value to voltage
    float voltage = result * conversion_factor;

    // Convert voltage to temperature using the LM35 conversion factor
    float temperature = 27 - (voltage - 0.706)/0.001721;  // LM35 has a 10 mV per degree Celsius scaling

    // Print the readings of the temperature
    printf("ADC Value: %u\n", result);
    printf("Voltage: %.4f V\n", voltage);
    printf("Temperature: %.2f degrees Celsius\n", temperature);

    // Your temperature-based control logic here
    if (temperature >= 50.0f) {
        // High temperature condition
        printf("High temperature condition\n");
        gpio_put(BUZZER_PIN, 1);  // Turn on the buzzer
        gpio_put(IN1_PIN, 0);     // Set IN1 to LOW
        gpio_put(IN2_PIN, 1);     // Set IN2 to HIGH
        gpio_put(EN_A_PIN, 1);    // Set ENA to HIGH
        gpio_put(bluePin,true);    // Set LED to HIGH
        fire = true;
    } else {
        // Normal temperature condition
        printf("Normal temperature condition\n");
        gpio_put(BUZZER_PIN, 0);  // Turn off the buzzer
        gpio_put(IN1_PIN, 0);     // Set IN1 to LOW
        gpio_put(IN2_PIN, 0);     // Set IN2 to LOW
        gpio_put(EN_A_PIN, 0);    // Set ENA to LOW
        gpio_put(bluePin,false);    // Set LED to LOW
        fire = false;
    }
}

//This is the main function that executes the 2 functions of the 2 sensors at the same time every 1 second
int main() {

    stdio_init_all();

    // Initialize LED pin and set it to be an output pin and LOW at the beginning
    gpio_init(redPin);
    gpio_set_dir(redPin, GPIO_OUT);
    gpio_put(redPin, false);

    // Initialize LED pin and set it to be an output pin and LOW at the beginning
    gpio_init(bluePin);
    gpio_set_dir(bluePin, GPIO_OUT);
    gpio_put(bluePin, false);


    // Configure ADC and the On-Board Temperature sensor
    adc_init();
    adc_set_temp_sensor_enabled(true);
    adc_select_input(4);

    //adc_gpio_init(DS18B20_PIN);

    //Smoke Sensor configuration to be an input pin
    gpio_init(FLAME_SENSOR_PIN);
    gpio_set_dir(FLAME_SENSOR_PIN, GPIO_IN);

    //Buzzer configuration to be an output pin
    gpio_init(BUZZER_PIN);
    gpio_set_dir(BUZZER_PIN, GPIO_OUT);
    gpio_put(BUZZER_PIN, 0); // Set buzzer low initially

    //Inputs and Enable of the DC Motor and setting the pins to be outputs
    gpio_init(IN1_PIN);
    gpio_set_dir(IN1_PIN, GPIO_OUT);

    gpio_init(IN2_PIN);
    gpio_set_dir(IN2_PIN, GPIO_OUT);

    gpio_init(EN_A_PIN);
    gpio_set_dir(EN_A_PIN, GPIO_OUT);
    gpio_put(EN_A_PIN, 0); //setting the enable to be low at first


    // pwm_config config = pwm_get_default_config();
    // pwm_config_set_clkdiv(&config, 16.0f); // Set the PWM clock divider
    // pwm_config_set_wrap(&config, 65535);    // Set the PWM wrap value
    // pwm_init(pwm_gpio_to_slice_num(EN_A_PIN), &config, true);

    //A while loop that runs te 2 functions every 1 second
    while (1) {
       Temp();
       flame();
       sleep_ms(1000);
    }
    return 0;
}

//////////////M01 code/////////////////////////////
/*while (true) {

      //The 3 LEDs are Off for the first 5 seconds
      gpio_put(redPin, false);
      gpio_put(greenPin, false);
      gpio_put(bluePin, false);
      sleep_ms(5000);

      //Only The red LED turns ON for 1 second
      gpio_put(redPin,true);
      sleep_ms(1000);
      gpio_put(redPin,false);

      //Only The green LED turns ON for 1 second
      gpio_put(greenPin,true);
      sleep_ms(1000);
      gpio_put(greenPin,false);

      //Only The blue LED turns ON for 1 second
      gpio_put(bluePin,true);
      sleep_ms(1000);
      gpio_put(bluePin,false);

      //Once the three LEDs are turned off again, turn on all the three LEDs together for 2 Seconds then Turn off all the LEDs.
      gpio_put(redPin, true);
      gpio_put(greenPin, true);
      gpio_put(bluePin, true);
      sleep_ms(2000);
    }*/